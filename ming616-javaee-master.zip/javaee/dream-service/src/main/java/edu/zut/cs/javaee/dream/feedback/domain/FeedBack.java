package edu.zut.cs.javaee.dream.feedback.domain;

public class FeedBack {

    String content;
    String customerId;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
}
