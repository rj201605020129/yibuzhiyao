package edu.zut.cs.javaee.dream.admin.service;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "edu.zut.cs.javaee.dream")
public class AdminServiceConfig {

}
