package edu.zut.cs.javaee.dream.admin.dao.impl;

import edu.zut.cs.javaee.dream.admin.dao.UserDao;
import edu.zut.cs.javaee.dream.admin.domain.User;

public class RoleDaoImpl implements UserDao {

    @Override
    public User getByUsername(String username) {
        // TODO Auto-generated method stub
        return null;
    }

}
