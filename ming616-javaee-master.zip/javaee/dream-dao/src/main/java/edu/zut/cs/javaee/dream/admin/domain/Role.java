package edu.zut.cs.javaee.dream.admin.domain;

public class Role {

}
