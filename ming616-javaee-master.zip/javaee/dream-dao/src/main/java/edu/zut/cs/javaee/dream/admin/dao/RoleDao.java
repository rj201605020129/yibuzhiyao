package edu.zut.cs.javaee.dream.admin.dao;

public interface RoleDao {

}
