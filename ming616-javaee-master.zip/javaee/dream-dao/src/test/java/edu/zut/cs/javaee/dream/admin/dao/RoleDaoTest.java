package edu.zut.cs.javaee.dream.admin.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.fail;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AdminDaoConfig.class)
class RoleDaoTest {

    @Test
    void test() {
        fail("Not yet implemented");
    }

}
